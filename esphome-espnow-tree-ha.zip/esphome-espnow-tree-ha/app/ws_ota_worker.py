from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .bridge_client import read_file_chunk
from .db import Database
from .firmware_store import FirmwareStore
from .models import (
    ABORTED,
    FAILED,
    QUEUED,
    REJOIN_TIMEOUT,
    STARTING,
    SUCCESS,
    TRANSFERRING,
    VERIFYING,
    VERSION_MISMATCH,
    WAITING_REJOIN,
    find_node_by_mac,
    is_terminal,
    normalize_mac,
    now_ts,
    parse_build_datetime,
)

if TYPE_CHECKING:
    from .bridge_ws_client import BridgeWsManager

logger = logging.getLogger(__name__)

WS_OTA_POLL_INTERVAL_S = 0.25
WS_OTA_STATUS_TIMEOUT_S = 10.0


class WsOTAWorker:
    def __init__(
        self,
        db: Database,
        ws_manager: BridgeWsManager,
        firmware_store: FirmwareStore,
        rejoin_timeout_s: int = 90,
        transfer_timeout_s: int = 300,
    ) -> None:
        self.db = db
        self.ws_manager = ws_manager
        self.firmware_store = firmware_store
        self.rejoin_timeout_s = rejoin_timeout_s
        self.transfer_timeout_s = transfer_timeout_s
        self._wake_event = asyncio.Event()
        self._stop_event = asyncio.Event()
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run(), name="ws-ota-worker")

    async def stop(self) -> None:
        self._stop_event.set()
        self._wake_event.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=2.0)
            except asyncio.TimeoutError:
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass

    def wake(self) -> None:
        self._wake_event.set()

    async def _run(self) -> None:
        await self._recover_startup()
        while not self._stop_event.is_set():
            job = self.db.active_job()
            if job and job["status"] in {STARTING, TRANSFERRING, VERIFYING, WAITING_REJOIN}:
                try:
                    await self._process(job)
                except Exception as exc:
                    self._fail(job["id"], f"WS OTA worker error: {exc}")
                continue
            self._wake_event.clear()
            try:
                await asyncio.wait_for(self._wake_event.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                pass

    async def _recover_startup(self) -> None:
        if self._stop_event.is_set():
            return
        job = self.db.active_job()
        if job and job["status"] not in {"pending_confirm", QUEUED}:
            self._fail(job["id"], "add-on restarted, active WS OTA job could not be recovered")
        if self.db.has_queued_jobs():
            logger.info("ws_ota_worker: queued jobs exist, will process after current")

    async def _process(self, job: dict[str, Any]) -> None:
        current = self.db.get_job(int(job["id"]))
        if not current or is_terminal(current["status"]):
            return

        if current["status"] == WAITING_REJOIN:
            await self._wait_for_rejoin(current)
            return

        path = Path(str(current.get("firmware_path") or ""))
        if not path.exists():
            self._fail(current["id"], "firmware file is missing")
            return

        if not self.ws_manager.connected:
            waited = 0
            while not self.ws_manager.connected and waited < 15:
                await asyncio.sleep(1.0)
                waited += 1
            if not self.ws_manager.connected:
                self._fail(current["id"], "bridge WebSocket not connected")
                return

        ota_client = self.ws_manager.ota_client
        if ota_client is None:
            waited_ota = 0
            while ota_client is None and waited_ota < 10:
                await asyncio.sleep(0.5)
                waited_ota += 0.5
                ota_client = self.ws_manager.ota_client
            if ota_client is None:
                self._fail(current["id"], "bridge WebSocket OTA client not available")
                return

        if current["status"] == STARTING:
            self.db.update_job(
                current["id"],
                started_at=now_ts(),
                percent=0,
                error_msg=None,
            )
            try:
                await ota_client.start(
                    target_mac=current["mac"],
                    file_size=int(current["firmware_size"]),
                    md5_hex=str(current["firmware_md5"]),
                    sha256_hex="",
                    filename=Path(current["firmware_path"]).name,
                )
            except Exception as exc:
                self._fail(current["id"], f"ota.start failed: {exc}")
                return

            self.db.update_job(current["id"], status=TRANSFERRING, bridge_state="TRANSFERRING")

        transfer_started = now_ts()
        consecutive_failures = 0

        total_chunks = ota_client.total_chunks
        if total_chunks == 0:
            total_chunks = (int(current["firmware_size"]) + 2048 - 1) // 2048
            self.db.update_job(current["id"], total_chunks=total_chunks)

        sent_seq = -1

        while not self._stop_event.is_set():
            latest = self.db.get_job(current["id"])
            if not latest or is_terminal(latest["status"]):
                return

            if now_ts() - transfer_started > self.transfer_timeout_s:
                await ota_client.abort("timeout")
                self._fail(current["id"], "OTA transfer timed out")
                return

            try:
                status = await ota_client.poll_status()
            except Exception as exc:
                consecutive_failures += 1
                if consecutive_failures >= 5:
                    await ota_client.abort("bridge_unreachable")
                    self._fail(
                        current["id"],
                        f"bridge unreachable after {consecutive_failures} consecutive failures: {exc}",
                    )
                    return
                await asyncio.sleep(1.0)
                continue
            consecutive_failures = 0

            state = str(status.get("state", "")).lower()
            percent = _bounded_percent(status.get("percent"))
            message = str(status.get("message", ""))

            updates: dict[str, Any] = {"bridge_state": state.upper(), "percent": percent}

            if state == "verifying":
                updates["status"] = VERIFYING
            elif state == "transferring":
                updates["status"] = TRANSFERRING
            elif state == "success":
                updates["status"] = WAITING_REJOIN
                updates["percent"] = 100
                self.db.update_job(current["id"], **updates)
                await self._wait_for_rejoin(self.db.get_job(current["id"]) or current)
                return
            elif state in ("failed", "aborted", "idle"):
                error_msg = message if message else f"bridge reported state: {state}"
                self._fail(current["id"], error_msg)
                return

            if message:
                updates["error_msg"] = message

            self.db.update_job(current["id"], **updates)

            next_seq = int(status.get("next_sequence", 0))
            window_size = int(status.get("window_size", 4))
            max_chunk = int(status.get("max_chunk_size", 2048))

            max_send_seq = min(next_seq + window_size - 1, total_chunks - 1)
            while sent_seq < max_send_seq:
                sent_seq += 1
                is_final = sent_seq == total_chunks - 1

                chunk = read_file_chunk(path, sent_seq, max_chunk)
                job_id_int = int(ota_client.job_id or "0", 16)

                from .ota_chunks import encode_chunk
                frame = encode_chunk(
                    job_id=job_id_int,
                    sequence=sent_seq,
                    payload=chunk,
                    max_chunk_size=max_chunk,
                    is_final=is_final,
                )
                await self.ws_manager.client.send_binary_frame(frame)

                chunks_sent = sent_seq + 1
                self.db.update_job(current["id"], chunks_sent=chunks_sent)

            await asyncio.sleep(WS_OTA_POLL_INTERVAL_S)

    async def _wait_for_rejoin(self, job: dict[str, Any]) -> None:
        target_mac = normalize_mac(str(job["mac"]))
        expected_build_date = str(job.get("parsed_build_date") or "").strip()
        expected_versions = {str(job.get("parsed_version") or "").strip()}
        expected_versions = {v for v in expected_versions if v}
        deadline = now_ts() + self.rejoin_timeout_s

        while now_ts() <= deadline and not self._stop_event.is_set():
            latest = self.db.get_job(job["id"])
            if not latest or is_terminal(latest["status"]):
                return

            try:
                topology_list = await self.ws_manager.topology(max_age_s=2.0)
            except Exception:
                await asyncio.sleep(3.0)
                continue

            node = find_node_by_mac(topology_list, target_mac)
            if node and bool(node.get("online")):
                current_build_date = str(node.get("firmware_build_date") or "").strip()
                current_version = str(
                    node.get("firmware_version") or node.get("sw_version") or ""
                ).strip()

                if expected_build_date and current_build_date:
                    expected_ts = parse_build_datetime(expected_build_date)
                    current_ts = parse_build_datetime(current_build_date)
                    if expected_ts is not None and current_ts is not None:
                        if abs(current_ts - expected_ts) > 1.0:
                            self._finish(
                                job["id"],
                                VERSION_MISMATCH,
                                f"device rejoined with build date {current_build_date}, expected {expected_build_date}",
                            )
                            return
                        self._finish(job["id"], SUCCESS, None)
                        return

                if expected_versions and current_version and current_version not in expected_versions:
                    self._finish(
                        job["id"],
                        VERSION_MISMATCH,
                        f"device rejoined with firmware {current_version}, expected {sorted(expected_versions)[0]}",
                    )
                    return
                self._finish(job["id"], SUCCESS, None)
                return

            await asyncio.sleep(3.0)

        self._finish(
            job["id"],
            REJOIN_TIMEOUT,
            "bridge transfer succeeded but the device did not rejoin before timeout",
        )

    def _finish(self, job_id: int, status: str, error_msg: str | None) -> None:
        job = self.db.get_job(job_id)
        if not job:
            return
        retained_path, retained_until = self.firmware_store.retain(
            job.get("firmware_path"), job_id
        )
        self.db.update_job(
            job_id, firmware_path=retained_path, retained_until=retained_until
        )
        self.db.mark_terminal(
            job_id,
            status,
            error_msg=error_msg,
            percent=100 if status == SUCCESS else job.get("percent"),
        )

    def _fail(self, job_id: int, message: str) -> None:
        retryable = any(
            tag in message.lower()
            for tag in [
                "not connected",
                "not available",
                "unreachable",
                "timeout",
                "connection refused",
            ]
        )
        if retryable:
            queued = self.db.queued_jobs()
            queue_order = len(queued)
            self.db.update_job(
                job_id,
                status=QUEUED,
                queue_order=queue_order,
                error_msg=f"WS OTA retryable: {message}",
            )
        else:
            self._finish(job_id, FAILED, message)


def _bounded_percent(value: Any) -> int:
    try:
        percent = int(value)
    except (TypeError, ValueError):
        return 0
    return max(0, min(100, percent))
